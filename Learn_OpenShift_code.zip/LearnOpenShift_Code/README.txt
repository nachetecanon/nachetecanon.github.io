#Learn OpenShift
Chapter 3, 4, and 5 does not contains code files!